[+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++]

Most asked Questions..

[1]
Q: How do i get key ?
A: Click get key: https://i.imgur.com/Hhg6XsM.png

[2]
Q: Is RIC a lua Script?
A: No, its not a script. Its a Internal Exploit built in C++ , there is no Lua used in RIC.  


[3]
Q: RIC is not Injecting, what do i do?
A: Make sure you have your Windows Defender, Antiviruses and Firewall disabled. Then try again and check if it works. If it still didn't work
   then download theses and install them, after you have installed em restart your computer.
   Download: 1: https://aka.ms/vs/16/release/vc_redist.x86.exe    |     2: https://aka.ms/vs/16/release/vc_redist.x64.exe


[4]
Q: I can't extract the folder, what do i do?
A: Install WinRar: https://www.win-rar.com/start.html?&L=0

[5]
Q: Is it safe it use ?
A: Yes, we are trusted and we have no 3rdparty downloads links in our software.

[6]
Q: I got BlackListed what now ?
A: If you got BlackListed, then you probably did something wrong. If you got any questions Ask Athoi or Duper.

[+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++]